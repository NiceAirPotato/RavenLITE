package me.kopamed.lunarkeystrokes.clickgui.raven.components;

public class ButtonBind {
   public static String bind = "Bind";
   public static String binding = "...";
}

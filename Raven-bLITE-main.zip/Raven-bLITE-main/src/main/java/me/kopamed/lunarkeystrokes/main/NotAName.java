package me.kopamed.lunarkeystrokes.main;

import me.kopamed.lunarkeystrokes.clickgui.kopagui.TabGui;
import me.kopamed.lunarkeystrokes.module.ModuleManager;
import me.kopamed.lunarkeystrokes.clickgui.raven.ClickGui;

public class NotAName {
   public static ModuleManager moduleManager;
   public static ClickGui clickGui;
   public static TabGui tabGui;
   private static final int c = -1;

   public NotAName() {
      moduleManager = new ModuleManager();
   }

   public ModuleManager getm0dmanager() {
      return moduleManager;
   }

   public static int pF() {
      return c;
   }
}

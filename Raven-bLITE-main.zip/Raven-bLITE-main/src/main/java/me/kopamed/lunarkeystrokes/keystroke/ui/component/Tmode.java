package me.kopamed.lunarkeystrokes.keystroke.ui.component;

public enum Tmode {
    TOPRESSED,
    TORELEASED,
    NONE;
}

package me.kopamed.lunarkeystrokes.clickgui.raven;

public class Component {
   public void draw() {
   }

   public void compute(int mousePosX, int mousePosY) {
   }

   public void mouseDown(int x, int y, int b) {
   }

   public void mouseReleased(int x, int y, int m) {
   }

   public void ky(char t, int k) {
   }

   public void setModuleStartAt(int n) {
   }

   public int getHeight() {
      return 0;
   }
}

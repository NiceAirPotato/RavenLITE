package me.superblaubeere27.client.notifications;

public enum NotificationType {
    INFO, WARNING, ERROR;
}
